let food=[
    {
        name:"Amul Taaza Toned Milk",
        quantity:"500ml",
        price:34
    }
     ,
    {
        name:"English Oven Bread",
        quantity:"400gm",
        price:45
     }
      ,
     {
         name:"India Gate Basmati Rice",
         quantity:"5kg",
         price:285
      }
      ,
      {
         name:"Eastern Chilli Powder",
         quantity:"100gm",
         price:35
       }
]


for(let i=0;i<food.length;i++)
   {
      console.log(food[i]);
    }

