let a  = 20
let b = 25


sum = a + b
diff = a - b
mul = a * b
div = a/b

console.log("The sum is",sum)
console.log("The diff is",diff)
console.log(mul)
console.log(div)
console.log("Division of", a, "/",b,"is", div)
console.log(`Divison of ${a}/${b} is ${div}`)